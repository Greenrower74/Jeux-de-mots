﻿Salut Raymond,

Je te laisse regarder le sujet ainsi que tous les fichiers .adb et .ads. J'ai mis des commentaires concernant la stratégie à adopter et j'ai commencé à créer des fonctions. Si ça ne te dérange pas je préférerai continuer sur la procédure Insertion() et te laisser faire Search_And_Display(). Voilà, si tu as des questions n'hésite pas.
